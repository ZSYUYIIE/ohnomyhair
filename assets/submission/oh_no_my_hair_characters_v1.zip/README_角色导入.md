# Oh No My Hair — 角色动作包 v1

这是一版用于接入试播的 AI 生成角色动作表。身体与头发已经合并，不含换发型功能。背景是真透明；预览中的黑底不是画入图片的底色。

## 文件

- assets/art/characters/p1/p1_sheet.png：双马尾角色，透明 RGBA PNG。
- assets/art/characters/p2/p2_sheet.png：前刺角色，透明 RGBA PNG。
- 每个角色各一个 *_frames.tres：Godot SpriteFrames 文本资源，已按下表切好动作及建议速度。
- 两张图实际均为 1086×1448，6列×8行，每格181×181。并非原计划的96px单帧最终图。

## 动作行表

每行从左到右6帧，行号从1开始。

| 行 | P1双马尾 | P2前刺 |
| --- | --- | --- |
| 1 | idle 待机 | idle 待机 |
| 2 | run 跑步 | run 跑步 |
| 3 | jump 起跳／上升 | jump 起跳／上升 |
| 4 | fall 下落 | fall 下落 |
| 5 | attack 甩发攻击 | parry 前刺弹反（该角色的攻击） |
| 6 | glide 螺旋桨滑翔 | dash 冲刺／头撞 |
| 7 | pull 头发拉动机关 | launch_charge 弹射蓄力 |
| 8 | carry_glide 吊队友滑翔姿势 | launch_release 弹射释放 |

动作表不包含机关、队友和投射物；这些继续由代码控制和组合。跳跃整行是动作演变，不表示一帧对应固定世界高度。

## 最快导入方式

1. 备份当前工程。
2. 解压，把包里的 assets 文件夹合并到 Godot 项目根目录；最终路径必须是 res://assets/art/characters/...，因为 .tres 已使用这些路径。
3. 打开 Godot，让 PNG 自动导入。为现有 Player 添加一个 AnimatedSprite2D 作为显示节点，保留原碰撞和移动脚本。
4. 将对应的 p1_frames.tres 或 p2_frames.tres 拖入 AnimatedSprite2D 的 Sprite Frames 属性。
5. 在 Inspector 或 SpriteFrames 面板试播 idle、run；代码中用 $AnimatedSprite2D.play("run") 等切换。
6. 先将显示节点缩放设为约 Vector2(0.53,0.53)，相当于每格约96×96游戏像素，再按你们的28×44碰撞箱检查实际身体比例。不要缩放整个 CharacterBody2D，否则碰撞也会改变。
7. 若玩家原点在脚底，居中精灵位置可先试 Vector2(0,-48)，再根据实际脚底对齐。这不是逐帧校准结果。
8. 左右朝向用 flip_h 控制，P1/P2标签放在不翻转的节点下。
9. 原脚本若还在绘制灰盒矩形，隐藏旧显示；不要删除碰撞节点。

## 若不使用预设 .tres

AnimatedSprite2D → 新建 SpriteFrames → 新建动作 → 从精灵表添加帧 → 横向6格、纵向8格 → 每个动作只选对应一行的6格。run/glide等可循环，attack/parry等一次性动作不要循环。表里的单格是181×181，不是256×256。

## 代码负责的部分

- 角色位移、跳跃高度、落地、攻击判定、伤害、无敌状态。
- 滑翔时的重力和最大下落速度。
- P1拉杆触发、抓住队友的位置、队友跟随和释放。
- P2冲刺撞墙判定、弹反时间窗、剪刀改向、队友弹射速度。
- 技能完成后返回idle/run/fall；一次性动画不要每帧从头重播。

## 本版限制与验收

- .tres 是按规则网格编写的便捷接入资源，未在你们实际工程中运行验证；如果文件路径不同，需要在Godot中修改纹理引用。
- AI生成的帧存在头部、脚底和轮廓变化，跑步接触姿态与跑跳根位置还未逐帧校正。规则切图不会自动消除抖动。
- 有些滑翔帧的头发靠近格边；逐格预览时检查是否被切断或串到相邻格。
- 跑步动作的腿部交替质量、前刺形状稳定性和动画首尾衔接需要实际试播；不能承诺这版已经是最终生产素材。
- 可先只用一帧待机、一帧跳跃和一帧下落；跑步、攻击和技能再逐项打开，减少接入排错。
- 如果抖动明显，后续需对特定帧做统一缩放、偏移或重画；可以用逐帧AtlasTexture的margin或独立帧资源整理，不能调整物理碰撞去追随画面漂移。
- 本批未提供受伤、死亡、坐椅、换发型、独立身体／头发图层，也没有额外的闪避动作；优先覆盖当前设定里的跑跳和两种发型能力。

## 生成规格摘要

使用内置图像生成，参考已确认的奶油色理发店预览。英文核心规格：Transparent RGBA character sprite sheet; 6 columns by 8 rows; consistent ivory circular head, dark purple single-stroke stick body; pink twin-tails or blue forward pompadour; flat marker colors; no scenery, captions or grid; combined body and hair; one action per row.
