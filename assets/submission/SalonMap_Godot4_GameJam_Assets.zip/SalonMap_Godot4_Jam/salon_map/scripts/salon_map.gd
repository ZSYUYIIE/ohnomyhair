extends Control
## Editor-visible UI. Change exported scene paths to wire in actual gameplay.
signal stage_selected(stage_id: int)
signal play_requested(stage_id: int)
signal back_requested

@export_file("*.tscn") var stage_1_scene: String = ""
@export_file("*.tscn") var stage_2_scene: String = ""
@export_file("*.tscn") var stage_3_scene: String = ""
@export_file("*.tscn") var stage_4_scene: String = ""
@export_file("*.tscn") var main_menu_scene: String = ""
@export var demo_mode: bool = true

const ProgressStore = preload("res://salon_map/scripts/progress_store.gd")
const UI := "res://salon_map/assets/ui/png/"
const STAGE_NAMES: Array[String] = ["Fresh Cut", "Return to Sender", "Wash & Blow-Dry", "Mystery Style"]
const BADGE_GOLD = preload(UI + "badge_gold.png")
const BADGE_LOCKED = preload(UI + "badge_lavender.png")
const BADGE_COMPLETE = preload(UI + "badge_complete.png")
const PILL_GOLD = preload(UI + "pill_gold.png")
const PILL_CREAM = preload(UI + "pill_cream.png")
const PILL_LAVENDER = preload(UI + "pill_lavender.png")

var selected_stage: int = 1
var completed_stages: int = 0
var _toast_generation: int = 0

func _ready() -> void:
	for i in range(1, 5):
		get_node("Stage%d/HitArea" % i).pressed.connect(_select_stage.bind(i))
		get_node("Stage%d/NameButton" % i).pressed.connect(_select_stage.bind(i))
	$UI/Play.pressed.connect(_play)
	$UI/Back.pressed.connect(_back)
	$Demo/Panel/Complete.pressed.connect(_demo_complete)
	$Demo/Panel/Cancel.pressed.connect(_close_demo)
	$TitleOverlay/Return.pressed.connect(_close_title)
	refresh_progress()

func refresh_progress() -> void:
	completed_stages = ProgressStore.get_completed()
	selected_stage = mini(selected_stage, mini(completed_stages + 1, 4))
	_refresh_ui()

func _refresh_ui() -> void:
	for i in range(1, 5):
		var stage: Control = get_node("Stage%d" % i)
		var locked: bool = i > completed_stages + 1
		var selected: bool = i == selected_stage
		stage.get_node("Ring").visible = selected
		stage.get_node("Lock").visible = locked
		stage.get_node("Check").visible = i <= completed_stages
		stage.get_node("Badge").texture = BADGE_COMPLETE if i <= completed_stages else (BADGE_LOCKED if locked else BADGE_GOLD)
		var button: TextureButton = stage.get_node("NameButton")
		button.texture_normal = PILL_GOLD if selected else (PILL_LAVENDER if locked else PILL_CREAM)
		button.get_node("Label").text = "???" if i == 4 and locked else STAGE_NAMES[i - 1]
		var hint := "Complete stage %d to unlock" % (i - 1) if locked else STAGE_NAMES[i - 1]
		button.tooltip_text = hint
		stage.get_node("HitArea").tooltip_text = hint
	$UI/StageName.text = STAGE_NAMES[selected_stage - 1]
	$UI/StageCount.text = "Stage %d / 4%s" % [selected_stage, "  -  Completed" if selected_stage <= completed_stages else ""]

func _select_stage(stage_id: int) -> void:
	if stage_id > completed_stages + 1:
		_toast("Complete stage %d to unlock this stage." % (stage_id - 1))
		return
	selected_stage = stage_id
	_refresh_ui()
	stage_selected.emit(stage_id)

func _play() -> void:
	play_requested.emit(selected_stage)
	# A connected handler may have taken responsibility for scene navigation.
	if not is_inside_tree() or get_tree().current_scene != self:
		return
	var scenes: Array[String] = [stage_1_scene, stage_2_scene, stage_3_scene, stage_4_scene]
	var path: String = scenes[selected_stage - 1]
	if not path.is_empty():
		if not ResourceLoader.exists(path):
			_toast("Scene path not found. Check the Inspector.")
			return
		get_tree().set_meta("salon_stage_id", selected_stage)
		var error := get_tree().change_scene_to_file(path)
		if error != OK:
			_toast("Could not open scene: %s" % error_string(error))
	elif demo_mode:
		$Demo/Panel/Heading.text = STAGE_NAMES[selected_stage - 1]
		$Demo.visible = true
		$Demo/Panel/Complete.grab_focus()
	else:
		_toast("Assign this stage's scene path in the Inspector.")

func _back() -> void:
	back_requested.emit()
	if not is_inside_tree() or get_tree().current_scene != self:
		return
	if main_menu_scene.is_empty():
		$TitleOverlay.visible = true
		$TitleOverlay/Return.grab_focus()
	elif ResourceLoader.exists(main_menu_scene):
		var error := get_tree().change_scene_to_file(main_menu_scene)
		if error != OK:
			_toast("Could not open menu: %s" % error_string(error))
	else:
		_toast("Main menu scene path not found.")

func _demo_complete() -> void:
	var error := ProgressStore.complete_stage(selected_stage)
	if error != OK:
		_toast("Could not save progress: %s" % error_string(error))
		return
	_close_demo()
	refresh_progress()
	_toast("Stage complete! All stages cleared." if completed_stages == 4 else "Stage complete! Next stage unlocked.")

func _close_demo() -> void:
	$Demo.visible = false
	$UI/Play.grab_focus()

func _close_title() -> void:
	$TitleOverlay.visible = false
	$UI/Back.grab_focus()

func _toast(message: String) -> void:
	_toast_generation += 1
	var generation := _toast_generation
	$Toast/Label.text = message
	$Toast.visible = true
	await get_tree().create_timer(2.8).timeout
	if generation == _toast_generation:
		$Toast.visible = false

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if $Demo.visible:
			_close_demo()
		elif $TitleOverlay.visible:
			_close_title()
		else:
			_back()
		get_viewport().set_input_as_handled()
