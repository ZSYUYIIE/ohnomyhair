extends RefCounted
## Self-contained save helper; no Autoload registration required.
const SAVE_PATH := "user://salon_map_progress.cfg"
const STAGE_COUNT := 4

static func get_completed() -> int:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return 0
	return clampi(int(config.get_value("progress", "completed", 0)), 0, STAGE_COUNT)

static func complete_stage(stage_id: int) -> Error:
	var completed := get_completed()
	if stage_id < 1 or stage_id > STAGE_COUNT or stage_id > completed + 1:
		return ERR_INVALID_PARAMETER
	var config := ConfigFile.new()
	config.set_value("progress", "completed", maxi(completed, stage_id))
	return config.save(SAVE_PATH)

static func reset() -> Error:
	var config := ConfigFile.new()
	config.set_value("progress", "completed", 0)
	return config.save(SAVE_PATH)
