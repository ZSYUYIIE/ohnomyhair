Oh No My Hair! — Ending review v1

7 clean opaque 1280x720 PNG panels in assets/. Total runtime 25 seconds.
Review contact sheet: ending_overall_preview_v1.png. Captions are added ONLY on the preview.
English subtitles: docs/ending_subtitles_en.srt. Shot02 intentionally has no subtitle.
Timing and shot descriptions: docs/ending_timeline.json and ending_storyboard.csv.
The final words retain the established ending: The barber offers to fix your hair. You look at each other... and say no. Bad hair. Good friends.
Use calm engine motion and check actual crops. Close-up torso/apron edges intentionally continue beyond the frame. No Godot playback test, video or audio file.
Status: approved for packaging. This archive contains the seven ending panels, captions, timeline and review preview.
